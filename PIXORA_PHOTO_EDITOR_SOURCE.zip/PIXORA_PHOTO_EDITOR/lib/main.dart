import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:gal/gal.dart';

void main() => runApp(const PixoraApp());

class PixoraApp extends StatefulWidget {
  const PixoraApp({super.key});
  @override
  State<PixoraApp> createState() => _PixoraAppState();
}

class _PixoraAppState extends State<PixoraApp> {
  ThemeMode _themeMode = ThemeMode.dark;

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF8B5CF6);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PIXORA Photo Editor',
      themeMode: _themeMode,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light), useMaterial3: true),
      darkTheme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark), useMaterial3: true),
      home: EditorHome(
        isDark: _themeMode == ThemeMode.dark,
        onThemeChanged: (dark) => setState(() => _themeMode = dark ? ThemeMode.dark : ThemeMode.light),
      ),
    );
  }
}

class EditorHome extends StatefulWidget {
  final bool isDark;
  final ValueChanged<bool> onThemeChanged;
  const EditorHome({super.key, required this.isDark, required this.onThemeChanged});

  @override
  State<EditorHome> createState() => _EditorHomeState();
}

class _EditorHomeState extends State<EditorHome> {
  final _picker = ImagePicker();
  File? _photo;
  double _brightness = 0;
  double _contrast = 1;
  double _saturation = 1;
  int _quarterTurns = 0;
  bool _busy = false;
  String _status = 'Choose a photo to start editing';

  Future<void> _pickImage() async {
    try {
      final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 100);
      if (picked == null) return;
      setState(() {
        _photo = File(picked.path);
        _brightness = 0;
        _contrast = 1;
        _saturation = 1;
        _quarterTurns = 0;
        _status = 'Photo loaded. Make your edits below.';
      });
    } catch (e) {
      _message('Could not open the gallery: $e');
    }
  }

  void _reset() {
    setState(() {
      _brightness = 0;
      _contrast = 1;
      _saturation = 1;
      _quarterTurns = 0;
      _status = 'Adjustments reset';
    });
  }

  void _rotate() => setState(() => _quarterTurns = (_quarterTurns + 1) % 4);

  List<double> _colorMatrix() {
    final c = _contrast;
    final s = _saturation;
    final b = _brightness * 255;
    const r = 0.213, g = 0.715, bl = 0.072;
    final sr = (1 - s) * r, sg = (1 - s) * g, sb = (1 - s) * bl;
    return <double>[
      (sr + s) * c, sg * c, sb * c, 0, b + 128 * (1 - c),
      sr * c, (sg + s) * c, sb * c, 0, b + 128 * (1 - c),
      sr * c, sg * c, (sb + s) * c, 0, b + 128 * (1 - c),
      0, 0, 0, 1, 0,
    ];
  }

  Future<void> _export() async {
    if (_photo == null || _busy) return;
    setState(() { _busy = true; _status = 'Processing your photo…'; });
    try {
      final bytes = await _photo!.readAsBytes();
      img.Image? decoded = img.decodeImage(bytes);
      if (decoded == null) throw Exception('Unsupported or damaged image.');
      if (_quarterTurns != 0) {
        decoded = img.copyRotate(decoded, angle: _quarterTurns * 90);
      }
      final b = _brightness;
      final c = _contrast;
      final s = _saturation;
      for (var y = 0; y < decoded.height; y++) {
        for (var x = 0; x < decoded.width; x++) {
          final p = decoded.getPixel(x, y);
          final oldR = p.r.toDouble();
          final oldG = p.g.toDouble();
          final oldB = p.b.toDouble();
          final gray = 0.213 * oldR + 0.715 * oldG + 0.072 * oldB;
          double adjust(double channel) {
            final saturated = gray + (channel - gray) * s;
            return (((saturated - 128) * c) + 128 + b * 255).clamp(0, 255);
          }
          decoded.setPixelRgb(x, y, adjust(oldR).round(), adjust(oldG).round(), adjust(oldB).round());
        }
      }
      final jpg = img.encodeJpg(decoded, quality: 95);
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/PIXORA_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(jpg, flush: true);
      await Gal.putImage(file.path);
      if (!mounted) return;
      setState(() { _status = 'Saved to your phone gallery in HD.'; });
      _message('Photo saved to Gallery successfully.');
    } catch (e) {
      if (mounted) {
        setState(() => _status = 'Export failed. Please try another photo.');
        _message('Could not save photo: $e');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Widget _slider(String title, double value, double min, double max, ValueChanged<double> onChanged, {String? valueText}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          Text(valueText ?? value.toStringAsFixed(2), style: TextStyle(color: Theme.of(context).colorScheme.primary)),
        ]),
        Slider(value: value, min: min, max: max, onChanged: _photo == null ? null : onChanged),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('PIXORA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
        actions: [
          IconButton(
            tooltip: widget.isDark ? 'Switch to light mode' : 'Switch to dark mode',
            onPressed: () => widget.onThemeChanged(!widget.isDark),
            icon: Icon(widget.isDark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
          children: [
            Text('Your Creativity. Your Photos. Your Freedom.', style: TextStyle(color: colors.onSurfaceVariant, fontSize: 13)),
            const SizedBox(height: 18),
            Container(
              height: 330,
              width: double.infinity,
              decoration: BoxDecoration(color: colors.surfaceContainerHighest, borderRadius: BorderRadius.circular(22)),
              clipBehavior: Clip.antiAlias,
              child: _photo == null
                  ? InkWell(
                      onTap: _pickImage,
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.add_photo_alternate_outlined, size: 58, color: colors.primary),
                        const SizedBox(height: 12),
                        const Text('Add a photo', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 5),
                        Text('Choose an image from your gallery', style: TextStyle(color: colors.onSurfaceVariant)),
                      ]),
                    )
                  : InteractiveViewer(
                      minScale: 0.5, maxScale: 4,
                      child: Center(
                        child: ColorFiltered(
                          colorFilter: ColorFilter.matrix(_colorMatrix()),
                          child: RotatedBox(quarterTurns: _quarterTurns, child: Image.file(_photo!, fit: BoxFit.contain)),
                        ),
                      ),
                    ),
            ),
            const SizedBox(height: 12),
            Text(_status, style: TextStyle(color: colors.onSurfaceVariant, fontSize: 12)),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: _pickImage, icon: const Icon(Icons.photo_library_outlined), label: const Text('Choose photo'))),
              const SizedBox(width: 10),
              OutlinedButton.icon(onPressed: _photo == null ? null : _rotate, icon: const Icon(Icons.rotate_right), label: const Text('Rotate')),
            ]),
            const SizedBox(height: 22),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Adjustments', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              TextButton.icon(onPressed: _photo == null ? null : _reset, icon: const Icon(Icons.restart_alt), label: const Text('Reset')),
            ]),
            _slider('Brightness', _brightness, -1, 1, (v) => setState(() => _brightness = v), valueText: '${(_brightness * 100).round()}'),
            _slider('Contrast', _contrast, 0, 2, (v) => setState(() => _contrast = v)),
            _slider('Saturation', _saturation, 0, 2, (v) => setState(() => _saturation = v)),
            const SizedBox(height: 10),
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                onPressed: _photo == null || _busy ? null : _export,
                icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.download_rounded),
                label: Text(_busy ? 'Processing…' : 'Save edited photo to Gallery'),
              ),
            ),
            const SizedBox(height: 16),
            Center(child: Text('PIXORA v1.0 • Free photo editing', style: TextStyle(color: colors.onSurfaceVariant, fontSize: 11))),
          ],
        ),
      ),
    );
  }
}
